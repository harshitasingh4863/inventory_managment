"""Advanced Inventory Management System | DSA mini project"""

from datetime import datetime


class Item:
    def __init__(self, code, name, quantity, price):
        self.code, self.name = code, name
        self.quantity, self.price = quantity, price

    def show(self):
        print(f"{self.code:<8} {self.name:<22} {self.quantity:>6}  Rs.{self.price:>10,.2f}")


class TreeNode:
    def __init__(self, item):
        self.item, self.left, self.right = item, None, None


class Inventory:
    def __init__(self):
        self.items = []
        self.root = None
        self.history = []  # doubly linked list: each entry is [text, previous, next]
        self.first = self.last = None
        self.requests = []  # FIFO queue, with a moving front index
        self.front = 0

    def log(self, message):
        entry = [f"{datetime.now():%H:%M:%S}  {message}", self.last, None]
        if self.last:
            self.last[2] = entry
        else:
            self.first = entry
        self.last = entry

    def rebuild_tree(self):
        ordered = sorted(self.items, key=lambda item: item.code)
        def build(lo, hi):
            if lo >= hi:
                return None
            mid = (lo + hi) // 2
            node = TreeNode(ordered[mid])
            node.left, node.right = build(lo, mid), build(mid + 1, hi)
            return node
        self.root = build(0, len(ordered))

    def find(self, code):
        node = self.root
        while node:
            if code == node.item.code:
                return node.item
            node = node.left if code < node.item.code else node.right
        return None

    def add(self, item):
        if self.find(item.code):
            raise ValueError("That item code already exists.")
        self.items.append(item)
        self.rebuild_tree()
        self.log(f"Added {item.code} ({item.name})")

    def remove(self, code):
        item = self.find(code)
        if not item:
            raise ValueError("Item code not found.")
        self.items.remove(item)
        self.rebuild_tree()
        self.log(f"Removed {code} ({item.name})")

    def change_stock(self, code, amount):
        item = self.find(code)
        if not item:
            raise ValueError("Item code not found.")
        if item.quantity + amount < 0:
            raise ValueError("Not enough stock for that change.")
        item.quantity += amount
        self.log(f"Stock for {code}: {amount:+d} (now {item.quantity})")

    def sort_items(self, field):
        # Bubble sort, included to demonstrate the algorithm.
        for end in range(len(self.items) - 1, 0, -1):
            swapped = False
            for i in range(end):
                if getattr(self.items[i], field) > getattr(self.items[i + 1], field):
                    self.items[i], self.items[i + 1] = self.items[i + 1], self.items[i]
                    swapped = True
            if not swapped:
                break

    def table(self, items=None):
        rows = self.items if items is None else items
        if not rows:
            print("  No items to show.")
            return
        print(f"\n{'CODE':<8} {'ITEM':<22} {'STOCK':>6}  {'UNIT PRICE':>13}")
        print("─" * 54)
        for item in rows:
            item.show()

    def show_history(self, reverse=False):
        node = self.last if reverse else self.first
        print("\nTransaction history (newest first):" if reverse else "\nTransaction history (oldest first):")
        if not node:
            print("  No transactions recorded.")
        while node:
            print(" ", node[0])
            node = node[1] if reverse else node[2]

    def process_restock(self):
        if self.front == len(self.requests):
            raise ValueError("Restock queue is empty.")
        code, amount = self.requests[self.front]
        self.front += 1
        self.change_stock(code, amount)
        print(f"Restocked {code} by {amount} units.")


def number(prompt, whole=False):
    value = float(input(prompt))
    if value < 0 or (whole and not value.is_integer()):
        raise ValueError("Enter a valid non-negative number.")
    return int(value) if whole else value


def main():
    stock = Inventory()
    for row in [("P101", "Laptop", 12, 58999), ("P102", "Wireless Mouse", 7, 799),
                ("P103", "Keyboard", 18, 1499), ("P104", "Monitor", 5, 12499)]:
        stock.add(Item(*row))

    menu = ["View inventory", "Add item", "Find item (BST)", "Change stock",
            "Remove item", "Sort inventory", "Low stock report", "Queue restock",
            "Process next restock", "View restock queue", "View transaction history",
            "Exit"]
    while True:
        print("\n╔════════ ADVANCED INVENTORY MANAGER ════════╗")
        for i, label in enumerate(menu, 1):
            print(f"║ {i:>2}. {label:<39}║")
        print("╚═══════════════════════════════════════════╝")
        try:
            choice = input("Select an option: ").strip()
            if choice == "1":
                stock.table()
            elif choice == "2":
                code = input("Item code: ").strip().upper()
                name = input("Item name: ").strip()
                if not code or not name:
                    raise ValueError("Code and name are required.")
                stock.add(Item(code, name, number("Starting quantity: ", True), number("Unit price (Rs.): ")))
                print("Item added.")
            elif choice == "3":
                item = stock.find(input("Item code: ").strip().upper())
                if item:
                    stock.table([item])
                else:
                    print("Item not found.")
            elif choice == "4":
                code = input("Item code: ").strip().upper()
                amount = int(input("Quantity change (+/-): "))
                stock.change_stock(code, amount)
                print("Stock updated.")
            elif choice == "5":
                stock.remove(input("Item code to remove: ").strip().upper())
                print("Item removed.")
            elif choice == "6":
                key = input("Sort by price or quantity? ").strip().lower()
                if key not in ("price", "quantity"):
                    raise ValueError("Choose 'price' or 'quantity'.")
                stock.sort_items(key)
                stock.table()
            elif choice == "7":
                limit = number("Show items at or below quantity (default 10): ", True)
                stock.table([item for item in stock.items if item.quantity <= limit])
            elif choice == "8":
                code = input("Item code: ").strip().upper()
                if not stock.find(code):
                    raise ValueError("Item code not found.")
                amount = number("Quantity to add: ", True)
                if amount == 0:
                    raise ValueError("Restock quantity must be greater than zero.")
                stock.requests.append((code, amount))
                print("Restock request queued.")
            elif choice == "9":
                stock.process_restock()
            elif choice == "10":
                pending = stock.requests[stock.front:]
                if not pending:
                    print("Restock queue is empty.")
                else:
                    for code, amount in pending:
                        print(f"  {code}: +{amount} units")
            elif choice == "11":
                stock.show_history()
            elif choice == "12":
                print("Goodbye. Inventory session closed.")
                break
            else:
                print("Choose a number from 1 to 12.")
        except ValueError as error:
            print(f"Input error: {error}")


if __name__ == "__main__":
    main()
